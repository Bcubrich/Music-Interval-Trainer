from cx_Freeze import setup, Executable
import os
os.environ['TCL_LIBRARY']=r'C:\Users\Bart\Anaconda3\tcl\tcl8.6'
os.environ['TK_LIBRARY']=r'C:\Users\Bart\Anaconda3\tcl\tk8.6'

import sys
base = 'Console'
if sys.platform == 'win32':
    base = 'Win32GUI'
additional_mods = ['numpy.core._methods', 'numpy.lib.format',"matplotlib.backends.backend_tkagg", 'matplotlib.pyplot', 'matplotlib.image', 'matplotlib.widgets']
setup(
    name = "Interval Trainer",
    version = "1.0.0",
    author = "Bart",
    author_email = "bcubrich@gmail.com",
    options = {"build_exe": {'includes': additional_mods,"packages":["pygame","tkinter",'random'],
                         "include_files": [
                         'Images/F cleff 8vb.png', 'Images/F cleff.png',
                         'Images/G cleff 8vb.png', 'Images/G cleff.png',
                         'Pitches/A#1.wav', 'Pitches/A#2.wav', 'Pitches/A#3.wav',
                         'Pitches/A#4.wav', 'Pitches/A#5.wav', 'Pitches/A1.wav',
                         'Pitches/A2.wav', 'Pitches/A3.wav', 'Pitches/A4.wav',
                         'Pitches/A5.wav', 'Pitches/Ab1.wav', 'Pitches/Ab2.wav',
                         'Pitches/Ab3.wav', 'Pitches/Ab4.wav', 'Pitches/B#2.wav',
                         'Pitches/B#3.wav', 'Pitches/B#4.wav', 'Pitches/B1.wav',
                         'Pitches/B2.wav', 'Pitches/B3.wav', 'Pitches/B4.wav',
                         'Pitches/B5.wav', 'Pitches/Bb1.wav', 'Pitches/Bb2.wav',
                         'Pitches/Bb3.wav', 'Pitches/Bb4.wav', 'Pitches/C#2.wav',
                         'Pitches/C#3.wav', 'Pitches/C#4.wav', 'Pitches/C#5.wav',
                         'Pitches/C2.wav', 'Pitches/C3.wav', 'Pitches/C4.wav',
                         'Pitches/C5.wav', 'Pitches/C6.wav', 'Pitches/D#2.wav',
                         'Pitches/D#3.wav', 'Pitches/D#4.wav', 'Pitches/D#5.wav',
                         'Pitches/D2.wav', 'Pitches/D3.wav', 'Pitches/D4.wav',
                         'Pitches/D5.wav', 'Pitches/Db1.wav', 'Pitches/Db2.wav',
                         'Pitches/Db3.wav', 'Pitches/Db4.wav', 'Pitches/E#2.wav',
                         'Pitches/E#3.wav', 'Pitches/E#4.wav', 'Pitches/E1.wav',
                         'Pitches/E2.wav', 'Pitches/E3.wav', 'Pitches/E4.wav',
                         'Pitches/E5.wav', 'Pitches/Eb2.wav', 'Pitches/Eb3.wav',
                         'Pitches/Eb4.wav', 'Pitches/F#1.wav', 'Pitches/F#2.wav',
                         'Pitches/F#3.wav', 'Pitches/F#4.wav', 'Pitches/F#5.wav',
                         'Pitches/F1.wav', 'Pitches/F2.wav', 'Pitches/F3.wav',
                         'Pitches/F4.wav', 'Pitches/F5.wav', 'Pitches/G#1.wav',
                         'Pitches/G#2.wav', 'Pitches/G#3.wav', 'Pitches/G#4.wav',
                         'Pitches/G#5.wav', 'Pitches/G1.wav', 'Pitches/G2.wav',
                         'Pitches/G3.wav', 'Pitches/G4.wav', 'Pitches/G5.wav',
                         'Pitches/Gb1.wav', 'Pitches/Gb2.wav', 'Pitches/Gb3.wav',
                         'Pitches/Gb4.wav']}},
    executables = [Executable("interval_trainer_v1.py", base=base)],
    )

#set TCL_LIBRARY=C:\Users\Bart\Anaconda3\tcl\tcl8.6
#set TK_LIBRARY=C:\Users\Bart\Anaconda3\tcl\tk8.6